/**
 * Renderiza un mini-calendario de cuadrante en un contenedor.
 * Reutilizable para: modal de gestión, preview en toolbar, modal de bulk/delete.
 *
 * @param {string} containerId - ID del div contenedor
 * @param {object} cuadrante  - { dias[], num_semanas, mes_referencia, anio_referencia }
 * @param {object} opts       - { selectable, selectedDates, onSelect, festivos }
 */
function renderCuadrantePreview(containerId, cuadrante, opts) {
  opts = opts || {};
  var container = document.getElementById(containerId);
  if (!container || !cuadrante || !cuadrante.dias) return;

  var selectedSet = new Set(opts.selectedDates || []);
  var dias = cuadrante.dias;
  var WEEKDAYS = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];

  // Agrupar por semana
  var semanas = {};
  dias.forEach(function (d) {
    if (!semanas[d.num_semana]) semanas[d.num_semana] = [];
    semanas[d.num_semana].push(d);
  });

  var html = '<div class="cuadrante-preview">';

  // Header con días de la semana
  html += '<div class="cuadrante-header d-flex gap-1 mb-1">';
  WEEKDAYS.forEach(function (wd, i) {
    var isWe = i >= 5;
    html += '<div class="cuadrante-header-cell text-center fw-bold small" style="' +
      'width:42px;min-width:42px;font-size:.7rem;' +
      (isWe ? 'color:#b71c1c' : 'color:#424242') + '">' + wd + '</div>';
  });
  html += '</div>';

  // Semanas
  Object.keys(semanas).sort(function (a, b) { return a - b; }).forEach(function (semNum) {
    html += '<div class="cuadrante-week d-flex gap-1 mb-1">';
    semanas[semNum].forEach(function (d) {
      var isWeekend = d.dia_semana >= 6;
      var isTraspaso = !d.es_del_mes_ref;
      var isFestivo = d.es_festivo;
      var isSelected = selectedSet.has(d.fecha);

      var bg = '#ffffff';
      var border = '1px solid #e0e0e0';
      var textColor = '#212529';
      var opacity = '1';

      if (isTraspaso) {
        bg = '#f5f5f5';
        textColor = '#9e9e9e';
        opacity = '0.7';
      }
      if (isWeekend) {
        bg = isTraspaso ? '#fff3e0' : '#fff8e1';
      }
      if (isFestivo) {
        bg = '#ffebee';
        border = '1px solid #ef9a9a';
      }
      if (isSelected) {
        bg = '#e3f2fd';
        border = '2px solid #1976d2';
      }

      var diaNum = d.dia || parseInt(d.fecha.slice(8, 10), 10);
      var mesNum = d.mes || parseInt(d.fecha.slice(5, 7), 10);

      html += '<label class="cuadrante-day text-center" style="' +
        'width:42px;min-width:42px;height:38px;' +
        'display:flex;flex-direction:column;align-items:center;justify-content:center;' +
        'border-radius:4px;cursor:' + (opts.selectable ? 'pointer' : 'default') + ';' +
        'background:' + bg + ';border:' + border + ';color:' + textColor + ';opacity:' + opacity + ';"' +
        (isFestivo && d.nombre_festivo ? ' title="' + d.nombre_festivo + '"' : '') + '>';

      if (opts.selectable) {
        html += '<input type="checkbox" class="cuadrante-day-check d-none" value="' + d.fecha + '"' +
          (isSelected ? ' checked' : '') + '>';
      }

      // Mostrar mes abreviado si es traspaso
      if (isTraspaso) {
        html += '<div style="font-size:.55rem;line-height:1;margin-bottom:-1px;">' +
          ['E','F','M','A','My','Jn','Jl','Ag','S','O','N','D'][mesNum - 1] + '</div>';
      }

      html += '<div style="font-size:.82rem;font-weight:' + (isFestivo ? '700' : '600') + ';line-height:1.1">' +
        diaNum + '</div>';

      if (isFestivo) {
        html += '<div style="font-size:.45rem;line-height:1;color:#c62828">●</div>';
      }

      html += '</label>';
    });
    html += '</div>';
  });

  // Leyenda
  html += '<div class="d-flex gap-3 mt-2" style="font-size:.65rem;color:#757575;">' +
    '<span><span style="display:inline-block;width:10px;height:10px;background:#fff;border:1px solid #e0e0e0;border-radius:2px;"></span> Mes ref.</span>' +
    '<span><span style="display:inline-block;width:10px;height:10px;background:#f5f5f5;border:1px solid #e0e0e0;border-radius:2px;opacity:.7;"></span> Traspaso</span>' +
    '<span><span style="display:inline-block;width:10px;height:10px;background:#fff8e1;border:1px solid #e0e0e0;border-radius:2px;"></span> Fin de semana</span>' +
    '<span><span style="display:inline-block;width:10px;height:10px;background:#ffebee;border:1px solid #ef9a9a;border-radius:2px;"></span> Festivo</span>' +
    '</div>';

  html += '</div>';
  container.innerHTML = html;

  // Bind selection events
  if (opts.selectable && typeof opts.onSelect === 'function') {
    container.querySelectorAll('.cuadrante-day').forEach(function (label) {
      label.addEventListener('click', function () {
        var cb = label.querySelector('.cuadrante-day-check');
        if (!cb) return;
        // toggle happens automatically for label>input
        var selected = Array.from(container.querySelectorAll('.cuadrante-day-check:checked'))
          .map(function (el) { return el.value; });
        opts.onSelect(selected);
      });
    });
  }
}