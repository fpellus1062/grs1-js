// Ejemplo del flujo de creación
function openNuevoCuadranteModal() {
  var app = window.GRS1Dashboard;
  var periodo = app._asig.getPeriodo();

  // Generar preview desde el API
  fetch('/api/cuadrantes/preview?anio=' + periodo.anio + '&mes=' + periodo.mes, {
    headers: app._asig.headers()
  })
  .then(function (res) { return res.json(); })
  .then(function (json) {
    var cuadrante = json.data;

    // Rellenar el formulario
    document.getElementById('cuadranteNombre').value = cuadrante.nombre;
    document.getElementById('cuadranteNumSemanas').value = cuadrante.num_semanas;
    document.getElementById('cuadranteRangoInfo').textContent =
      cuadrante.fecha_inicio + ' → ' + cuadrante.fecha_fin +
      ' (' + cuadrante.num_semanas + ' semanas, ' + cuadrante.dias.length + ' días)';

    // Renderizar preview
    renderCuadrantePreview('cuadrantePreviewContainer', cuadrante);

    // Mostrar modal
    bootstrap.Modal.getOrCreateInstance(
      document.getElementById('modalNuevoCuadrante')
    ).show();
  });
}